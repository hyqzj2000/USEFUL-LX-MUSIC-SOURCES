/**
 * @name fish_music(解密版)
 * @description 交流群组:https://t.me/yus_share
 * @version 1.0.2
 * @author 大鱼吃小鱼，TZB679
 */

const {
  EVENT_NAMES: ka,
  request: Ca,
  on: a,
  send: b,
  env: c,
  version: d
} = globalThis.lx;
const Ea = {
  "128k": "128kmp3",
  "320k": "320kmp3",
  flac: "2000kflac",
  flac24bit: "4000kflac"
};
const e = ["128k", "320k", "flac", "flac24bit"];
const h = {
  "128k": 128,
  "320k": 320,
  flac: 740,
  flac24bit: 999
};
const f = ["128k", "320k", "flac", "flac24bit"];
const g = ["128k", "320k", "flac", "flac24bit"];
const i = ["128k", "320k", "flac", "flac24bit"];
const j = ["128k", "320k", "flac"];
const k = {
  "128k": {
    quality: 128,
    format: "mp3"
  },
  "320k": {
    quality: 320,
    format: "mp3"
  },
  flac: {
    quality: 1000,
    format: "flac"
  }
};
const l = {
  "128k": ["standard"],
  "320k": ["exhigh"],
  flac: ["lossless"],
  flac24bit: ["hires"]
};
const m = {
  "128k": ["128k"],
  "320k": ["320k"],
  flac: ["flac"],
  flac24bit: ["flac24bit"]
};
const n = {
  "128k": ["普通"],
  "320k": ["HQ高品质"],
  flac: ["SQ无损"],
  flac24bit: ["臻品母带", "臻品全景声", "臻品2.0"]
};
const o = {
  "128k": ["128k"],
  "320k": ["320k"],
  flac: ["flac"],
  flac24bit: ["master", "atmos_plus", "atmos"]
};
const p = {
  "128k": [],
  "320k": ["8", "9"],
  flac: ["10"],
  flac24bit: ["16", "14", "13", "12", "11"]
};
const q = {
  "128k": ["5"],
  "320k": ["6", "5"],
  flac: ["8"],
  flac24bit: ["7", "9", "10"]
};
const r = "https://github.com/CharlesPikachu/musicdl/releases/download/keys/baimusic.txt";
const s = "music.gdstudio.xyz";
const t = "https://" + s + "/api.php";
const u = "https://" + s + "/time";
const v = "20260510";
const w = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36";
const x = ["78993344b9bf1105655599009cdba3d2", "ce778eb0d1858edfb4b2071a115f1edf"];
const y = ["28fece925439b052792a97989c870ced3803a71c6b534f71e5a5338b2d31ef8", "c4c4f5fc36bad4cacb98839e14fea40277b35ea2eb1babdad7bbde128400f3b1"];
const z = "ZK76QJCIH5PPICJOOXUH";
let A = null;
const B = (b, a) => new Promise((g, c) => {
  Ca(b, a, (d, a, b) => {
    if (d) {
      return c(d);
    }
    const e = {
      resp: a || {},
      body: b
    };
    g(e);
  });
});
const C = (c, a) => B(c, a).then(({
  resp: c,
  body: a
}) => {
  if (a !== undefined) {
    return a;
  }
  if (c && c.body !== undefined) {
    return c.body;
  }
  return c;
});
const D = c => Object.keys(c).map(a => encodeURIComponent(a) + "=" + encodeURIComponent(c[a])).join("&");
const E = c => {
  const a = c.indexOf("?");
  if (a < 0) {
    return c;
  } else {
    return c.slice(0, a);
  }
};
const F = b => /^https?:\/\//i.test(String(b || ""));
const G = b => String(b || "").replace(/\\?u0026/gi, "&").replace(/\\&/g, "&").replace(/\$/g, "&");
const H = b => G(b).trim();
const I = (d, a) => {
  const b = d && d.headers || {};
  return b[a] || b[a.toLowerCase()] || b[a.toUpperCase()] || "";
};
const J = (d, e) => {
  const b = H(d);
  if (F(b)) {
    return b;
  }
  if (b.startsWith("//")) {
    return "https:" + b;
  }
  if (b.startsWith("/")) {
    const c = String(e || "").match(/^https?:\/\/[^/]+/i);
    if (c) {
      return c[0] + b;
    } else {
      return b;
    }
  }
  return b;
};
const K = e => {
  if (typeof e === "string") {
    try {
      return JSON.parse(e);
    } catch (a) {
      const b = e.match(/url['"]?\s*[:=]\s*['"]([^'"]+)['"]/i);
      const c = e.match(/bitrate['"]?\s*[:=]\s*([0-9]+)/i);
      return {
        data: {
          url: b ? b[1] : "",
          bitrate: c ? Number(c[1]) : 1
        }
      };
    }
  }
  return e || {};
};
const L = (d, a) => {
  let b = d;
  for (const c of a) {
    if (b == null) {
      return undefined;
    }
    b = b[c];
  }
  return b;
};
const M = (d, a) => {
  for (const e of a) {
    let a = L(d, e);
    if (Array.isArray(a)) {
      a = a[0];
    }
    a = H(a);
    if (F(a)) {
      return a;
    }
  }
  return "";
};
const N = async (c, a) => K(await C(c, a));
const O = async (h, a, b, c, d) => {
  const e = await N(a, b);
  const f = M(e, c);
  if (!f || d && d(f, e)) {
    const a = e && (e.msg || e.message || e.error || e.errMsg);
    throw new Error(h + " failed: " + (a || "no url"));
  }
  return f;
};
const P = async d => {
  let c = null;
  for (const a of d) {
    try {
      return await a();
    } catch (b) {
      c = b;
    }
  }
  throw c || new Error(
  //decode_error: _0x15a0d6 is not defined
  "all parsers failed");
};
const Q = () => {
  if (!A) {
    const c = {
      "User-Agent": w
    };
    const a = {
      method: "GET",
      timeout: 12000,
      headers: c
    };
    A = C(r, a).then(b => String(b || "").trim());
  }
  return A;
};
const R = n => {
  const p = (e, a) => {
    const b = (e & 65535) + (a & 65535);
    const c = (e >> 16) + (a >> 16) + (b >> 16);
    return c << 16 | b & 65535;
  };
  const b = (c, a) => c << a | c >>> 32 - a;
  const o = (c, a, d, e, f, g) => p(b(p(p(a, c), p(e, g)), f), d);
  const q = (d, a, b, c, e, f, g) => o(a & b | ~a & c, d, a, e, f, g);
  const e = (d, a, b, c, e, f, g) => o(a & c | b & ~c, d, a, e, f, g);
  const f = (d, a, b, c, e, f, g) => o(a ^ b ^ c, d, a, e, f, g);
  const g = (d, a, b, c, e, f, g) => o(b ^ (a | ~c), d, a, e, f, g);
  const a = e => {
    const a = [];
    const b = e.length * 8;
    for (let c = 0; c < b; c += 8) {
      a[c >> 5] |= (e.charCodeAt(c / 8) & 255) << c % 32;
    }
    return a;
  };
  const c = d => {
    let a = "";
    for (let b = 0; b < d.length * 32; b += 8) {
      a += String.fromCharCode(d[b >> 5] >>> b % 32 & 255);
    }
    return a;
  };
  const d = (b, a) => {
    b[a >> 5] |= 128 << a % 32;
    b[(a + 64 >>> 9 << 4) + 14] = a;
    let h = 1732584193;
    let r = -271733879;
    let s = -1732584194;
    let t = 271733878;
    for (let d = 0; d < b.length; d += 16) {
      const a = h;
      const c = r;
      const i = s;
      const j = t;
      h = q(h, r, s, t, b[d], 7, -680876936);
      t = q(t, h, r, s, b[d + 1], 12, -389564586);
      s = q(s, t, h, r, b[d + 2], 17, 606105819);
      r = q(r, s, t, h, b[d + 3], 22, -1044525330);
      h = q(h, r, s, t, b[d + 4], 7, -176418897);
      t = q(t, h, r, s, b[d + 5], 12, 1200080426);
      s = q(s, t, h, r, b[d + 6], 17, -1473231341);
      r = q(r, s, t, h, b[d + 7], 22, -45705983);
      h = q(h, r, s, t, b[d + 8], 7, 1770035416);
      t = q(t, h, r, s, b[d + 9], 12, -1958414417);
      s = q(s, t, h, r, b[d + 10], 17, -42063);
      r = q(r, s, t, h, b[d + 11], 22, -1990404162);
      h = q(h, r, s, t, b[d + 12], 7, 1804603682);
      t = q(t, h, r, s, b[d + 13], 12, -40341101);
      s = q(s, t, h, r, b[d + 14], 17, -1502002290);
      r = q(r, s, t, h, b[d + 15], 22, 1236535329);
      h = e(h, r, s, t, b[d + 1], 5, -165796510);
      t = e(t, h, r, s, b[d + 6], 9, -1069501632);
      s = e(s, t, h, r, b[d + 11], 14, 643717713);
      r = e(r, s, t, h, b[d], 20, -373897302);
      h = e(h, r, s, t, b[d + 5], 5, -701558691);
      t = e(t, h, r, s, b[d + 10], 9, 38016083);
      s = e(s, t, h, r, b[d + 15], 14, -660478335);
      r = e(r, s, t, h, b[d + 4], 20, -405537848);
      h = e(h, r, s, t, b[d + 9], 5, 568446438);
      t = e(t, h, r, s, b[d + 14], 9, -1019803690);
      s = e(s, t, h, r, b[d + 3], 14, -187363961);
      r = e(r, s, t, h, b[d + 8], 20, 1163531501);
      h = e(h, r, s, t, b[d + 13], 5, -1444681467);
      t = e(t, h, r, s, b[d + 2], 9, -51403784);
      s = e(s, t, h, r, b[d + 7], 14, 1735328473);
      r = e(r, s, t, h, b[d + 12], 20, -1926607734);
      h = f(h, r, s, t, b[d + 5], 4, -378558);
      t = f(t, h, r, s, b[d + 8], 11, -2022574463);
      s = f(s, t, h, r, b[d + 11], 16, 1839030562);
      r = f(r, s, t, h, b[d + 14], 23, -35309556);
      h = f(h, r, s, t, b[d + 1], 4, -1530992060);
      t = f(t, h, r, s, b[d + 4], 11, 1272893353);
      s = f(s, t, h, r, b[d + 7], 16, -155497632);
      r = f(r, s, t, h, b[d + 10], 23, -1094730640);
      h = f(h, r, s, t, b[d + 13], 4, 681279174);
      t = f(t, h, r, s, b[d], 11, -358537222);
      s = f(s, t, h, r, b[d + 3], 16, -722521979);
      r = f(r, s, t, h, b[d + 6], 23, 76029189);
      h = f(h, r, s, t, b[d + 9], 4, -640364487);
      t = f(t, h, r, s, b[d + 12], 11, -421815835);
      s = f(s, t, h, r, b[d + 15], 16, 530742520);
      r = f(r, s, t, h, b[d + 2], 23, -995338651);
      h = g(h, r, s, t, b[d], 6, -198630844);
      t = g(t, h, r, s, b[d + 7], 10, 1126891415);
      s = g(s, t, h, r, b[d + 14], 15, -1416354905);
      r = g(r, s, t, h, b[d + 5], 21, -57434055);
      h = g(h, r, s, t, b[d + 12], 6, 1700485571);
      t = g(t, h, r, s, b[d + 3], 10, -1894986606);
      s = g(s, t, h, r, b[d + 10], 15, -1051523);
      r = g(r, s, t, h, b[d + 1], 21, -2054922799);
      h = g(h, r, s, t, b[d + 8], 6, 1873313359);
      t = g(t, h, r, s, b[d + 15], 10, -30611744);
      s = g(s, t, h, r, b[d + 6], 15, -1560198380);
      r = g(r, s, t, h, b[d + 13], 21, 1309151649);
      h = g(h, r, s, t, b[d + 4], 6, -145523070);
      t = g(t, h, r, s, b[d + 11], 10, -1120210379);
      s = g(s, t, h, r, b[d + 2], 15, 718787259);
      r = g(r, s, t, h, b[d + 9], 21, -343485551);
      h = p(h, a);
      r = p(r, c);
      s = p(s, i);
      t = p(t, j);
    }
    return [h, r, s, t];
  };
  const h = f => {
    const a = "0123456789abcdef";
    let b = "";
    for (let c = 0; c < f.length; c++) {
      const d = f.charCodeAt(c);
      b += a.charAt(d >>> 4 & 15) + a.charAt(d & 15);
    }
    return b;
  };
  const i = unescape(encodeURIComponent(String(n)));
  return h(c(d(a(i), i.length * 8)));
};
const S = d => {
  const a = d.meta || {};
  const b = d.songmid || a.songId || d.hash || a.hash || d.id || a.id || d.rid || d.musicrid || "";
  return String(b).replace(/^MUSIC_/, "");
};
const T = async (d, a) => {
  const b = await C(d, a);
  return K(b);
};
const U = (d, a) => {
  const b = String(Number(a) || Date.now()).slice(0, 9);
  return R(s + "|" + v + "|" + b + "|" + d).slice(-8).toUpperCase();
};
const V = async (j, a) => {
  const b = {
    method: "GET",
    timeout: 10000
  };
  const c = await C(u, b);
  const d = U(a, c);
  const e = {
    ...j
  };
  e.s = d;
  const f = D(e);
  const g = {
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    Origin: "https://" + s,
    Referer: "https://" + s + "/",
    "User-Agent":
    //decode_error: _0xa14021 is not defined
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "X-Requested-With":
    //decode_error: _0xa14021 is not defined
    "XMLHttpRequest"
  };
  const h = {
    method: "POST",
    timeout: 15000,
    headers: g,
    body: f
  };
  return T(t, h);
};
const W = async (g, a) => {
  const b = S(g);
  const c = Ea[a];
  if (!b) {
    throw new Error("kw song id missing");
  }
  if (!c) {
    throw new Error(
    //decode_error: _0x29a3a0 is not defined
    "unsupported quality");
  }
  const d = {
    type: "convert_url_with_sign",
    br: c,
    rid: b
  };
  d.source = "kwplayercar_ar_6.0.0.9_B_jiakong_vh.apk";
  d.user = "7e09dbb97053f47e";
  const e = D(d);
  const f = "https://nmobi.kuwo.cn/mobi.s?f=web&" + e;
  const h = {
    method: "GET",
    timeout: 15000,
    headers: {
      "User-Agent":
      //decode_error: _0x29a3a0 is not defined
      "okhttp/3.10.0"
    }
  };
  const i = await C(f, h);
  const j = K(i);
  const k = G(j && j.data ? j.data.url : "");
  if (!k.startsWith("http")) {
    throw new Error("kw local failed: " + (j && j.msg ? j.msg :
    //decode_error: _0x29a3a0 is not defined
    "no url"));
  }
  return E(k);
};
const X = async (i, a) => {
  const b = S(i);
  const c = h[a];
  if (!b) {
    throw new Error("wy song id missing");
  }
  if (!c) {
    throw new Error("unsupported quality");
  }
  const d = {
    types:
    //decode_error: _0x417dd6 is not defined
    "url",
    id: b,
    source: "netease",
    br: c
  };
  const e = await V(d, encodeURIComponent(b));
  const f = G(e && e.url ? e.url : "");
  if (!f.startsWith("http")) {
    throw new Error("wy gd failed: " + (e && e.detail ? e.detail : "no url"));
  }
  return f;
};
const Y = async (g, a) => {
  const h = l[a] || l.flac;
  if (!h.length) {
    throw new Error(
    //decode_error: _0x151ae2 is not defined
    "kg haitang unsupported quality: " + a);
  }
  const b = ["https://musicapi.haitangw.net/kgqq/kg.php", "https://music.haitangw.cc/kgqq/kg.php"];
  const i = [];
  for (const c of b) {
    for (const a of h) {
      const b = {
        [
        //decode_error: _0x151ae2 is not defined
        "User-Agent"]: w
      };
      const e = {
        method: "GET",
        timeout: 15000,
        headers: b
      };
      i.push(() => O("kg haitang " + a, c + "?" + D({
        type: "json",
        id: g,
        level: a
      }), e, [["data", "url"], ["url"]]));
    }
  }
  return P(i);
};
const Z = async (g, a) => {
  const h = await Q();
  const b = m[a] || m.flac;
  const c = {
    "User-Agent": w
  };
  c.Accept = "application/json";
  c.Referer = "http://api.liuyunidc.cn/baimusic/";
  const d = {
    method: "GET",
    timeout: 15000,
    headers: c
  };
  return P(b.map(a => () => O("kg liuyun " + a, "https://api.liuyunidc.cn/baimusic/musicurl.php?" + D({
    source: "kg",
    musicId: g,
    quality: a,
    card: h
  }), d, [["url"], ["data", "url"]])));
};
const $ = (e, a) => {
  const b = e.meta || {};
  const c = e._types && e._types[a] || b._qualitys && b._qualitys[a] || {};
  return String(c.hash || b.hash || e.hash || e.fileHash || e.FileHash || "").trim();
};
const _ = async (e, a) => {
  if (!g.includes(a)) {
    throw new Error("unsupported quality");
  }
  const b = $(e, a);
  if (!b) {
    throw new Error(
    //decode_error: _0x292adf is not defined
    "kg hash missing");
  }
  const c = [() => Z(b, a)];
  if ((l[a] || []).length) {
    c.unshift(() => Y(b, a));
  }
  return P(c);
};
const aa = async (f, a) => {
  const b = n[a] || n.flac;
  const c = {
    "User-Agent": w
  };
  const d = {
    method: "GET",
    timeout: 15000,
    headers: c
  };
  return P(b.map((a, b) => () => O("tx xcvts " + a, "https://api.xcvts.cn/api/music/qq?" + D({
    apiKey: x[b % x.length],
    mid: f,
    type: a
  }), d, [["data", "music"], ["data", "url"], ["url"]])));
};
const ba = async (g, a) => {
  const h = await Q();
  const b = o[a] || o.flac;
  const c = {
    "User-Agent": w
  };
  c.Accept =
  //decode_error: _0x1d1ee2 is not defined
  "application/json";
  c.Referer = "http://api.liuyunidc.cn/baimusic/";
  const d = {
    method: "GET",
    timeout: 15000,
    headers: c
  };
  return P(b.map(a => () => O("tx liuyun " + a, "https://api.liuyunidc.cn/baimusic/musicurl.php?" + D({
    source: "tx",
    musicId: g,
    quality: a,
    card: h
  }), d, [["url"], ["data", "url"]])));
};
const ca = async (f, a) => {
  const b = p[a] || p.flac;
  if (!b.length) {
    throw new Error("tx vkeys unsupported quality: " + a);
  }
  const c = {
    "User-Agent": w
  };
  const d = {
    method: "GET",
    timeout: 15000,
    headers: c
  };
  return P(b.map(a => () => O("tx vkeys " + a, "https://api.vkeys.cn/music/tencent/song/link?" + D({
    mid: f,
    quality: a
  }), d, [["data", "url"], ["url"]])));
};
const da = {
  "User-Agent": w
};
const ea = {
  method: "GET",
  timeout: 15000,
  headers: da
};
const fa = async c => P(y.map(a => () => O("tx nki", "https://api.nki.pw/API/music_open_api.php?" + D({
  mid: c,
  apikey: a
}), ea, [["song_play_url_sq"], ["song_play_url_pq"], ["song_play_url_accom"], ["song_play_url_hq"], ["song_play_url"], ["song_play_url_standard"], ["song_play_url_fq"]])));
const ga = {
  "User-Agent": w
};
const ha = {
  method: "GET",
  timeout: 15000,
  headers: ga
};
const ia = async b => O("tx tang", "https://tang.api.s01s.cn/music_open_api.php?" + D({
  mid: b
}), ha, [["song_play_url_sq"], ["song_play_url_pq"], ["song_play_url_accom"], ["song_play_url_hq"], ["song_play_url"], ["song_play_url_standard"], ["song_play_url_fq"]]);
const ja = async (f, a) => {
  const b = q[a] || q.flac;
  const c = {
    "User-Agent": w
  };
  const d = {
    method: "GET",
    timeout: 15000,
    headers: c
  };
  return P(b.map(a => () => O("tx 317ak " + a, "https://api.317ak.cn/api/yinyue/qqyinyue?" + D({
    ckey: z,
    i: f,
    br: a,
    type: "json",
    lrc: "1"
  }), d, [["url"], ["data", "url"]])));
};
const la = async (e, a) => {
  const b = S(e);
  if (!b) {
    throw new Error(
    //decode_error: _0x1e473d is not defined
    "tx song id missing");
  }
  if (!i.includes(a)) {
    throw new Error("unsupported quality");
  }
  const c = [() => aa(b, a), () => ba(b, a), () => ja(b, a)];
  if ((p[a] || []).length) {
    c.splice(2, 0, () => ca(b, a));
  }
  if (a === "flac") {
    c.splice(3, 0, () => fa(b), () => ia(b));
  }
  return P(c);
};
const ma = (e, a) => {
  const b = k[a];
  if (!b) {
    throw new Error("unsupported quality");
  }
  if (!e) {
    throw new Error("mg song id missing");
  }
  const c = {
    ID: e,
    quality: b.quality,
    format: b.format
  };
  return "https://music.wjhe.top/api/music/migu/url?" + D(c);
};
const na = async (i, a) => {
  const b = ma(i, a);
  const c = {
    "User-Agent": w,
    Accept: "*/*"
  };
  const d = {
    method: "HEAD",
    timeout: 15000,
    headers: c
  };
  const {
    resp: e
  } = await B(b, d);
  const f = J(I(e,
  //decode_error: _0x3dfe61 is not defined
  "location"), b);
  if (F(f)) {
    return f;
  }
  const g = H(e && e.url);
  if (F(g) && !g.includes("music.wjhe.top/api/music/migu/url")) {
    return g;
  }
  throw new Error("mg wjhe failed: no direct url");
};
const oa = e => {
  const a = e.meta || {};
  const b = [e.songmid, e.songId, a.songId, e.contentId, e.contentid, a.contentId, a.contentid, e.id, a.id, e.rid, e.musicrid];
  const c = {};
  return b.map(b => String(b || "").replace(/^MUSIC_/, "").trim()).filter(b => b && !c[b] && (c[b] = true));
};
const pa = async g => {
  const a = {
    "User-Agent": w,
    Accept: "application/json"
  };
  a["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8";
  a.Origin = "https://music.migu.cn";
  a.Referer = "https://music.migu.cn/";
  const b = {
    resourceId: g
  };
  const c = await N("https://c.musicapp.migu.cn/MIGUM2.0/v1.0/content/resourceinfo.do?resourceType=2", {
    method: "POST",
    timeout: 15000,
    headers: a,
    body: D(b)
  });
  const d = Array.isArray(c.resource) ? c.resource : [];
  const e = d[0] && d[0].songId;
  if (!e) {
    throw new Error("mg official resourceinfo failed: no songId");
  }
  return String(e);
};
const qa = async c => {
  const a = oa(c);
  if (!a.length) {
    throw new Error("mg song id missing");
  }
  for (const b of a) {
    if (/^[0-9]{1,10}$/.test(b)) {
      return b;
    }
  }
  return P(a.map(b => () => pa(b)));
};
const ra = async (c, a) => {
  if (!j.includes(a)) {
    throw new Error("unsupported quality");
  }
  return na(await qa(c), a);
};
a(ka.request, ({
  action: e,
  source: a,
  info: b
}) => {
  if (e !== "musicUrl") {
    return Promise.reject("action not support");
  }
  const c = a === "kw" ? W : a === "wy" ? X : a === "kg" ? _ : a === "tx" ? la : a === "mg" ? ra : null;
  if (!c) {
    return Promise.reject("source not support");
  }
  return c(b.musicInfo, b.type).catch(b => {
    console.log(b);
    return Promise.reject(b);
  });
});
const sa = {
  name: "kw",
  type: "music",
  actions: ["musicUrl"],
  qualitys: e
};
const ta = {
  name: "wy",
  type: "music",
  actions: ["musicUrl"],
  qualitys: f
};
const ua = {
  name: "kg",
  type: "music",
  actions: ["musicUrl"],
  qualitys: g
};
const va = {
  name: "tx",
  type: "music",
  actions: ["musicUrl"],
  qualitys: i
};
const wa = {
  name: "mg",
  type: "music",
  actions: ["musicUrl"],
  qualitys: j
};
const xa = {
  kw: sa,
  wy: ta,
  kg: ua,
  tx: va,
  mg: wa
};
const ya = {
  sources: xa
};
const za = ya;
if (c !== "mobile") {
  za.openDevTools = false;
}
b(ka.inited, za);
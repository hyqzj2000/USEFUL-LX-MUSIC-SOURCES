/**
 * @name 洛雪音乐源(解密版)
 * @description 支持QQ音乐、酷狗音乐、酷我音乐、网易云音乐、咪咕音乐五大平台
 * @version 1.0.0 v2-fix
 * @author Sereinf 解混淆 BY Toskysun
 */

const { EVENT_NAMES, request, on, send } = globalThis.lx;

const qualityMap = {
  tx: {
    '128k': '6',
    '320k': '8',
    flac: '10',
    flac24bit: '11',
  },
  kg: {
    '128k': '128k',
    '320k': '320k',
    flac: 'flac',
    flac24bit: 'flac24bit',
  },
  kw: {
    '128k': '128kmp3',
    '320k': '320kmp3',
    flac: '2000kflac',
    flac24bit: '4000kflac',
  },
  wy: {
    '128k': 'standard',
    '320k': 'exhigh',
    flac: 'lossless',
    flac24bit: 'hires',
  },
  mg: {
    '128k': 'PQ',
    '320k': 'HQ',
  },
};

/**
 * @param {string} url
 * @param {object} options
 * @returns {Promise<any>} 响应 body
 */
function httpRequest(url, options) {
  return new Promise((resolve, reject) => {
    request(url, options, (err, res) => {
      if (err) return reject(err);
      resolve(res.body);
    });
  });
}

const apis = {
  tx: {
    async musicUrl({ songmid }, quality) {
      let url =
        'https://api.vkeys.cn/v2/music/tencent/geturl?mid=' +
        songmid +
        '&quality=' +
        quality;
      const { data } = await httpRequest(url, { method: 'GET' });
      if (data?.url) return data.url;

      const qualityCodeToName = {
        6: '128k',
        8: '320k',
        10: 'flac',
        11: 'flac24bit',
      };
      url =
        'https://88.lxmusic.中国/lxmusicv3/url/tx/' +
        songmid +
        '/' +
        qualityCodeToName[quality];
      return httpRequest(url, { method: 'GET' }).then((body) => body.data);
    },
  },

  kg: {
    musicUrl({ hash }, quality) {
      const url =
        'https://88.lxmusic.中国/lxmusicv3/url/kg/' + hash + '/' + quality;
      return httpRequest(url, { method: 'GET' }).then((body) => body.data);
    },
  },

  kw: {
    musicUrl({ songmid }, quality) {
      const url =
        'https://nmobi.kuwo.cn/mobi.s?f=web&user=0&source=kwplayer_ar_8.5.5.0_jiakong.apk&type=convert_url_with_sign&br=' +
        quality +
        '&rid=' +
        songmid;
      return httpRequest(url, { method: 'GET' }).then(
        (body) => body.data.url.split('?')[0]
      );
    },
  },

  wy: {
    async musicUrl({ songmid }, quality) {
      let url =
        'https://api.cenguigui.cn/api/netease/music_v1.php?type=json&id=' +
        songmid +
        '&level=' +
        quality;
      const { data } = await httpRequest(url, { method: 'GET' });
      if (data?.url) return data.url;

      url = 'https://wyapi.toubiec.cn/api/music/url';
      const result = await httpRequest(url, {
        method: 'POST',
        headers: {
          Origin: 'https://wyapi.toubiec.cn',
          Referer: 'https://wyapi.toubiec.cn/',
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
        },
        body: JSON.stringify({ id: songmid, level: quality }),
      });
      if (result?.data?.[0]?.url) return result.data[0].url;

      const brMap = {
        standard: '128',
        exhigh: '320',
        lossless: '999',
        hires: '999',
      };
      url =
        'https://music-api.gdstudio.xyz/api.php?types=url&source=netease&id=' +
        songmid +
        '&br=' +
        brMap[quality];
      return httpRequest(url, { method: 'GET' }).then((body) => body.url);
    },
  },

  mg: {
    async musicUrl({ copyrightId }, quality) {
      let url =
        'https://c.musicapp.migu.cn/MIGUM2.0/v1.0/content/resourceinfo.do?resourceType=2&copyrightId=' +
        copyrightId;
      const {
        resource: [{ contentId }],
      } = await httpRequest(url, { method: 'GET' });

      url =
        'https://c.musicapp.migu.cn/MIGUM3.0/strategy/listen-url/v2.3?resourceType=2&toneFlag=PQ&contentId=' +
        contentId;
      return httpRequest(url, {
        method: 'GET',
        headers: { channel: '0140210' },
      }).then((body) =>
        quality === 'HQ'
          ? body.data.url.replace('MP3_128', 'MP3_320')
          : body.data.url
      );
    },
  },
};

on(EVENT_NAMES.request, ({ source, info }) => {
  return apis[source]
    .musicUrl(info.musicInfo, qualityMap[source][info.type])
    .catch((err) => Promise.reject(err));
});

send(EVENT_NAMES.inited, {
  sources: {
    tx: {
      name: 'QQ音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k', 'flac', 'flac24bit'],
    },
    kg: {
      name: '酷狗音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k', 'flac', 'flac24bit'],
    },
    kw: {
      name: '酷我音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k', 'flac', 'flac24bit'],
    },
    wy: {
      name: '网易云音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k', 'flac', 'flac24bit'],
    },
    mg: {
      name: '咪咕音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k'],
    },
  },
});
